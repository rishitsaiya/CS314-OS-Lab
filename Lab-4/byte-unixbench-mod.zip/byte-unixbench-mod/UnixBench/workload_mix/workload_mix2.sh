#!/bin/sh
./arithoh.sh &
./arithoh.sh &
./fstime.sh &
./syscall.sh &
./syscall.sh &
wait