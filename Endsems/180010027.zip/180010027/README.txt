# README.txt - Rishit Saiya 180010027


I have used 'include <bits/stdc++.h>' library in `master-worker.c`. So while compiling the code, the following command was used:

```
g++ master-worker.c -lpthread
```

Note: This hasn't changed the fact that all the test cases are passed and Synchronization Primitives are correctly implemented.